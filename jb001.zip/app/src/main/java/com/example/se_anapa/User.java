package com.example.se_anapa;

import androidx.annotation.NonNull;

public class User {

    public String myName;
    public String myID;
    public String myPS;
    public String myHt; //내가 좋아요 한 해시태그. 로그인 기능이 추가되면서 필요해짐
    public String myViews;
    public String myLikes;
    public String myScraps;
    public String myMemo; //장보기 메모

    public User() {

    }

    public User(String myName, String myID, String myPS, String myHt, String myViews, String myLikes, String myScraps, String myMemo) {

        this.myName = myName;
        this.myID = myID;
        this.myPS = myPS;
        this.myHt = myHt;
        this.myViews = myViews;
        this.myLikes = myLikes;
        this.myScraps = myScraps;
        this.myMemo = myMemo;
    }

    public String getMyName()
    {
        return myName;
    }

    public void setMyName(String myName)
    {
        this.myName = myName;
    }

    public String getMyID()
    {
        return myID;
    }

    public void setMyID(String myID)
    {
        this.myID = myID;
    }

    public String getMyPS()
    {
        return myPS;
    }

    public void setMyPS(String myPS)
    {
        this.myPS = myPS;
    }

    public String getMyHt()
    {
        return myHt;
    }

    public void setMyHt(String myHt)
    {
        this.myHt = myHt;
    }

    public String getMyViews()
    {
        return myViews;
    }

    public void setMyViews(String myViews)
    {
        this.myViews = myViews;
    }

    public String getMyLikes()
    {
        return myLikes;
    }

    public void setMyLikes(String myLikes)
    {
        this.myLikes = myLikes;
    }


    public String getMyScraps()
    {
        return myScraps;
    }

    public void setMyScraps(String myScraps)
    {
        this.myScraps = myScraps;
    }

    public String getMyMemo()
    {
        return myMemo;
    }

    public void setMyMemo(String myMemo)
    {
        this.myMemo = myMemo;
    }

    @NonNull
    @Override
    public String toString() {
        return "User{" + "myName='" + myName + '\'' + "myID='" + myID + '\'' + "myPS='" + myPS + '\'' + "myHt='" + myHt + '\'' + "myViews='" + myViews + '\'' + ", myLikes='" + myLikes + '\'' +
                ", ='" +  + '\'' + ", myScraps='" + myScraps + '\'' + ", myMemo='" + myMemo + '\'' + '}';
    }

}
