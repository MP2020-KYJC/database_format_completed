package com.example.se_anapa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login_Activity extends AppCompatActivity {

    Button btn_signUp;
    Button btn_login;
    Button btn_find_id;
    Button btn_find_password;
    EditText edit_id;
    EditText edit_password;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn_signUp = (Button)findViewById(R.id.btn_register);
        btn_login = (Button)findViewById(R.id.btn_login);
        btn_find_id = (Button)findViewById(R.id.find_id);
        btn_find_password = (Button)findViewById(R.id.find_password);
        edit_id = (EditText)findViewById(R.id.edit_id);
        edit_password = (EditText)findViewById(R.id.edit_password);
        mDatabase = FirebaseDatabase.getInstance().getReference();

        btn_signUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Sign_Up_Activity.class);
                startActivity(intent);
            }
        });

//        btn_find_id.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getApplicationContext(),Find_ID_Activity.class);
//                startActivity(intent);
//            }
//        });
//
//        btn_find_password.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getApplicationContext(),Find_Password_Activity.class);
//                startActivity(intent);
//            }
//        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

    }

//    private void readUser(final String ID) {
//        mDatabase.child("users").child(ID).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                if(dataSnapshot.getValue(User.class) != null){
//                    User post = dataSnapshot.getValue(User.class);
//                    if(edit_id.getText().toString().equals(post.userID)) {
//                        if(edit_password.getText().toString().equals(post.userPassword)) {
//                            //Intent intent = new Intent(getApplicationContext(),ChoiceActivity.class);
//                            //Bundle bundle = new Bundle();
//                            //String text_id = edit_id.getText().toString();
//                            //bundle.putString("id",text_id);
//                            //intent.putExtras(bundle);
//                            //startActivity(intent);
//                            //finish();
//                        } else {
//                            Toast.makeText(getApplicationContext(), "<잘못된 패스워드입니다>", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                } else {
//                    Toast.makeText(getApplicationContext(), "<등록되지않은 아이디입니다>", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//
//        });
//    }

}
