package com.example.se_anapa;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Sign_Up_Activity extends AppCompatActivity {

    RadioGroup HnP;
    EditText myViews;
    EditText myLikes;
    EditText myScraps;
    EditText myMemo;
    Button duplication_btn;
    Button register_btn;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        HnP = (RadioGroup) findViewById(R.id.kind_radio);
        myViews = (EditText) findViewById(R.id.name_input);
        myLikes = (EditText) findViewById(R.id.id_input);
        myScraps = (EditText) findViewById(R.id.password_input);
        myMemo = (EditText) findViewById(R.id.email_input);
        duplication_btn = (Button) findViewById(R.id.duplication_btn);
        register_btn = (Button) findViewById(R.id.register);
        mDatabase = FirebaseDatabase.getInstance().getReference();

//        duplication_btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                readUser(myViews.getText().toString());
//            }
//        });

        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //User
                String myName = "피카츄";
                String myID = "pika77";
                String myPS = "pikapika";
                String myHt = "h001-h002-h003";
                String myViews = "r001-r002";
                String myLikes = "r002";
                String myScraps = "-";
                String myMemo = "케참 사기";

//                HashMap result = new HashMap<>();
//                result.put("name", myName);
//                result.put("name", myViews);
//                result.put("ID", myLikes);
//                result.put("password", myScraps);
//                result.put("email", myMemo);

                //Contents
                String ctID = "r003";
                String ctTitle = "꿔바로우";
                String ctIg = "식용유-등심-감자전분-물-달걀-소금-후추-생강-간장-설탕-식초-대파-당근-레몬";
                String ctText = "* 튀김\n" +
                        "\n" +
                        "식용유(튀김용) 1.8L\n" +
                        "돈등심 500g\n" +
                        "감자전분 2컵(240g)\n" +
                        "물 1컵과2큰술(200g)\n" +
                        "달걀물 2큰술(20g)\n" +
                        "맛소금 적당량\n" +
                        "후춧가루 적당량\n" +
                        "\n" +
                        "* 소스\n" +
                        "\n" +
                        "식용유 2큰술(14g)\n" +
                        "간생강 1/2큰술(8g)\n" +
                        "진간장 2큰술(20g)\n" +
                        "설탕 5큰술(50g)\n" +
                        "식초 5큰술(50g)\n" +
                        "물 4큰술(40g)\n" +
                        "대파 적당량\n" +
                        "당근 적당량\n" +
                        "레몬 적당량-1. 돈등심은 0.3cm 두께로 잘라 준비한다.-2. 대파는 6cm 길이로 심지를 제거하고 가늘게 채 썬다.-3. 돈등심에 맛소금, 후추를 뿌려 밑간한다.-4. 감자전분, 달걀물, 물을 섞어 튀김반죽을 만든다.-5. 기름을 170도 정도로 예열하고 돈등심에 반죽을 입힌다.-6. 예열된 기름에 넣어 2차 튀김 해준 후 기름을 뺀다.-7. 프라이팬에 식용유를 두르고 간 생강을 넣어 볶는다.-8. 향이 올라오면 간장, 물, 설탕을 넣어 끓인다.-9. 소스가 끓으면 레몬, 당근, 대파를 넣고 소스를 졸인다.-10. 소스가 살짝 농도 나게 졸여지면 튀긴 고기를 넣고 볶아 완성한다.";
                String ctImage = "@drawable/Guobaorou00-@drawable/Guobaorou01-@drawable/Guobaorou02-@drawable/Guobaorou03-@drawable/Guobaorou04-@drawable/Guobaorou05-@drawable/Guobaorou06-@drawable/Guobaorou07-@drawable/Guobaorou08-@drawable/Guobaorou09";
                String ctReference = "https://youtu.be/3OwIXlvjjyk";
                String ctHashtag = "h004";

//                HashMap result1 = new HashMap<>();
//                result1.put("kind", myName);
//                result1.put("name", myViews);
//                result1.put("ID", myLikes);
//                result1.put("password", myScraps);
//                result1.put("email", myMemo);

                String htID = "h004";
                String htName = "튀김";
                String htLikes = "1";
                String htScraps = "1";

//                HashMap result = new HashMap<>();
//                result.put("kind", myName);
//                result.put("name", myViews);
//                result.put("ID", myLikes);
//                result.put("password", myScraps);
//                result.put("email", myMemo);

                String igID = "i003";
                String igName = "돼지고기";
                String igAddedDate = "20/06/16";
                String igExpiration = "21/06/20";
                String igIsAdded = "1";
                String igImage = "@drawble/meat";

//                HashMap result = new HashMap<>();
//                result.put("kind", myName);
//                result.put("name", myViews);
//                result.put("ID", myLikes);
//                result.put("password", myScraps);
//                result.put("email", myMemo);

                writeNewUser(myName, myID, myPS, myHt, myViews, myLikes, myScraps, myMemo);
                writeNewContents(ctID, ctTitle, ctIg, ctText, ctImage, ctReference, ctHashtag);
                writeNewIngredients(igID, igName, igAddedDate, igExpiration, igIsAdded, igImage);
                writeNewHashtags(htID, htName, htLikes, htScraps);
                finish();
            }
        });

    }

    private void writeNewUser(String myName, String myID, String myPS, String myHt, String myViews, String myLikes, String myScraps, String myMemo) {
        User user = new User(myName, myID, myPS, myHt, myViews, myLikes, myScraps, myMemo);

        mDatabase.child("User").child(myName).setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장완료>", Toast.LENGTH_SHORT).show();
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장실패>", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void writeNewContents(String ctID, String ctTitle, String ctIg, String ctText, String ctImage, String ctReference, String ctHashtag) {
        Contents contents = new Contents(ctID, ctTitle, ctIg, ctText, ctImage, ctReference, ctHashtag);

        mDatabase.child("Contents").child(ctID).setValue(contents).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장완료>", Toast.LENGTH_SHORT).show();
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장실패>", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void writeNewIngredients(String igID, String igName, String igAddedDAte, String igExpiration, String igIsAdded, String igImage) {
        Ingredients ingredients = new Ingredients(igID, igName, igAddedDAte, igExpiration, igIsAdded, igImage);

        mDatabase.child("Ingredients").child(igID).setValue(ingredients).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장완료>", Toast.LENGTH_SHORT).show();
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장실패>", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void writeNewHashtags(String htID, String htName, String htLikes, String htScraps) {
        Hashtag hashtag = new Hashtag(htID, htName, htLikes, htScraps);

        mDatabase.child("Hashtags").child(htID).setValue(hashtag).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장완료>", Toast.LENGTH_SHORT).show();
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Sign_Up_Activity.this, "<데이터베이스 저장실패>", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}




//
//    private void readUser(final String ID) {
//        mDatabase.child("users").child(ID).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                if(dataSnapshot.getValue(User.class) != null){
//                    User post = dataSnapshot.getValue(User.class);
//                    if(ID.equals(post.myLikes)) {
//                        Toast.makeText(getApplicationContext(), "<중복된 아이디>", Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Toast.makeText(getApplicationContext(), "<사용가능한 아이디>", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//    }



