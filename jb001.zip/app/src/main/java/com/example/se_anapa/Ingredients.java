package com.example.se_anapa;

import androidx.annotation.NonNull;

public class Ingredients {

    public String igID;
    public String igName;
    public String igAddedDate; //재료 추가한 날짜
    public String igExpiration; //재료 유통기한
    public String igIsAdded; //나에게 있는 재료인지
    public String igImage; //재료 이미지

    public Ingredients() {

    }

    public Ingredients(String igID, String igName, String igAddedDate, String igExpiration, String igIsAdded, String igImage) {

        this.igID = igID;
        this.igName = igName;
        this.igAddedDate = igAddedDate;
        this.igExpiration = igExpiration;
        this.igIsAdded = igIsAdded;
        this.igImage = igImage;
    }

    public String getIgID()
    {
        return igID;
    }

    public void setIgID(String igID)
    {
        this.igID = igID;
    }

    public String getIgName()
    {
        return igName;
    }

    public void setIgName(String igName)
    {
        this.igName = igName;
    }

    public String getIgAddedDate()
    {
        return igAddedDate;
    }

    public void setIgAddedDate(String igAddedDate)
    {
        this.igAddedDate = igAddedDate;
    }

    public String getIgExpiration()
    {
        return igExpiration;
    }

    public void setIgExpiration(String igExpiration)
    {
        this.igExpiration = igExpiration;
    }

    public String getIgIsAdded()
    {
        return igIsAdded;
    }

    public void setIgIsAdded(String igIsAdded)
    {
        this.igIsAdded = igIsAdded;
    }

    public String getIgImage()
    {
        return igImage;
    }

    public void setIgImage(String myMemo)
    {
        this.igImage = igImage;
    }

    @NonNull
    @Override
    public String toString() {
        return "User{" + "igID='" + igID + '\'' + "igName='" + igName + '\'' + ", igAddedDate='" + igAddedDate + '\'' +
                ", igExpiration='" + igExpiration + '\'' + ", igIsAdded='" + igIsAdded + '\'' + ", igImage='" + igImage + '\'' + '}';
    }

}
