package com.example.se_anapa;

import androidx.annotation.NonNull;

public class Hashtag {

    public String htID;
    public String htName;
    public String htLikes;
    public String htScraps;

    public Hashtag() {

    }

    public Hashtag(String htID, String htName, String htLikes, String htScraps) {

        this.htID = htID;
        this.htName = htName;
        this.htLikes = htLikes;
        this.htScraps = htScraps;
    }

    public String getHtID()
    {
        return htID;
    }

    public void setHtID(String htID)
    {
        this.htID = htID;
    }

    public String getHtName()
    {
        return htName;
    }

    public void setHtName(String htName)
    {
        this.htName = htName;
    }

    public String getHtLikes()
    {
        return htLikes;
    }

    public void setHtLikes(String htLikes)
    {
        this.htLikes = htLikes;
    }

    public String getHtScraps()
    {
        return htScraps;
    }

    public void setHtScraps(String htScraps)
    {
        this.htScraps = htScraps;
    }


    @NonNull
    @Override
    public String toString() {
        return "Hashtag{" + "htID='" + htID + '\'' + "htName='" + htName + '\'' + ", htLikes='" + htLikes + '\'' +
                ", htScraps='" + htScraps + '\'' + '}';
    }

}
