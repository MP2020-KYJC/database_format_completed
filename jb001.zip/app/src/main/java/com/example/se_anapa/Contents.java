package com.example.se_anapa;

import androidx.annotation.NonNull;

public class Contents {

    public String ctID;
    public String ctTitle;
    public String ctIg;
    public String ctText;
    public String ctImage;
    public String ctReference;
    //public String ctLastSee; //최근 본 게시글 표시할 때 사용할 변수 - 걍 myViews로 해결
    public String ctHashtag;

    public Contents() {

    }

    public Contents(String ctID, String ctTitle, String ctIg, String ctText, String ctImage, String ctReference, String ctHashtag) {

        this.ctID = ctID;
        this.ctTitle = ctTitle;
        this.ctIg = ctIg;
        this.ctText = ctText;
        this.ctImage = ctImage;
        this.ctReference = ctReference;
        this.ctHashtag = ctHashtag;
    }

    public String getCtID()
    {
        return ctID;
    }

    public void setCtID(String ctID)
    {
        this.ctID = ctID;
    }

    public String getCtTitle()
    {
        return ctTitle;
    }

    public void setCtTitle(String ctTitle)
    {
        this.ctTitle = ctTitle;
    }

    public String getCtIg()
    {
        return ctIg;
    }

    public void setCtIg(String ctIg)
    {
        this.ctIg = ctIg;
    }

    public String getCtText()
    {
        return ctText;
    }

    public void setCtText(String ctText)
    {
        this.ctText = ctText;
    }

    public String getCtImage()
    {
        return ctImage;
    }

    public void setCtImage (String ctImage)
    {
        this.ctImage = ctImage;
    }

    public String getCtReference()
    {
        return ctReference;
    }

    public void setCtReference(String ctReference)
    {
        this.ctReference = ctReference;
    }

    public String getCtHashtag()
    {
        return ctHashtag;
    }

    public void setCtHashtag(String ctHashtag)
    {
        this.ctHashtag = ctHashtag;
    }
//
//
//    public String getCtLastSee()
//    {
//        return ctLastSee;
//    }
//
//    public void setCtLastSee(String ctReference)
//    {
//        this.ctLastSee = ctLastSee;
//    }

    @NonNull
    @Override
    public String toString() {
        return "Contents{" + "ctID='" + ctID + '\'' + "ctTitle='" + ctTitle + '\'' + ", ctText='" + ctText + '\'' +
                ", ctImage='" + ctImage + '\'' + ", ctReference='" + ctReference + '\'' + "ctHashtag='" + ctHashtag + '\'' +'}';
    }

}
